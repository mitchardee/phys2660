typedef struct {
   short left;
   short right;
} sample;
